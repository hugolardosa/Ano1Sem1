/*
 * JAM, 5-nov-2018
 * teste 1 - dúvidas
 */
import java.util.Scanner;

public class Duvidas2 {

    static Scanner ler = new Scanner(System.in);

    public static void main(String[] args) {

        //~int x= ler.nextInt();
        //~tabuada(x);
        String a="*";
        String b=ler.nextLine();
        printNvezes(6,a,a);
        printNvezes(6,a,b);
        System.out.printf("%b %n",bissexto(2018));






    }
    static boolean bissexto(int ano){
        return ano % 400 == 0 || (ano % 4 == 0 && ano %100 != 0);

    }
    static int diasMes(int ano, int mes){
        int ndias=0;
        if (mes == 1 || mes == 3)ndias = 31;
        if (mes == 4 || mes == 6)ndias = 30;
        if (mes == 2){
            ndias = 28;
            if (bissexto(ano))ndias = 29;
        }
        return ndias;
    }
 static void tabuada(int n){
     //~Scanner ler2 = new Scanner(System.in);
    int y=ler.nextInt();
    for (int i=1;i<=10;i++)System.out.printf("%2d x %2d = %3d%n",n,i,n*i);
}








    // funções
    public static void printNvezes(int n,String s1, String s2) {
        System.out.print(s1);
        for (int i=0; i<n-2; i++)System.out.print(s2);
        System.out.println(s1);
    }
    public static void printRet(int lar, int alt) {
        printNvezes(lar,"*","*");
        for (int l=0; l<alt-2; l++)printNvezes(lar,"*"," ");
        printNvezes(lar,"*","*");
    }
    // f gerar sequencia de nº aleatórios entre -10.0 e 10.0 e det max, min, zeros
    static String  sequencia(int npontos) {
        int  nraizes = 0;
        double y, y0;
        String raizes="";

        y0 = -10 + Math.random()*20;
        double max=y0;
        double min=y0;
        for (int i = 0; i < npontos; i++) {
            y = -10 + Math.random()*20;
            if ((y0 > 0 && y <= 0) || (y0 < 0 && y >= 0)) {
                nraizes = nraizes + 1;
            }
            if (y > max)max=y;
            if (y < min)min=y;
            y0 = y;
        }
        raizes = raizes + "Maximo= "+max+" Minimo= "+min+" Zeros= "+nraizes;
        return raizes;
    }


}
