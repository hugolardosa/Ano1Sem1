class Aluno1{
	int id;
	String nome;
	double nota;
}
